# Weight & BMI with data granular

Dataset: Weight & BMI - Body Summary - Body Health

Data: "weight_kg_float"
      "bmi_float"

Data Sources: Fitbit

## Frame dataset

![descarga (20)](https://github.com/SalvatoreCordano/DataStructure/assets/147050219/7754480c-3458-40dd-95d8-878fbd26e495)

![descarga (21)](https://github.com/SalvatoreCordano/DataStructure/assets/147050219/75fdcbf5-42df-4b3c-b9ba-6a74cfed3444)


```Json
        "version": 2,
        "data_structure": "body_summary",
        "client_uuid": "d892043b-e2bf-45d1-a678-d0276c8a9535",
        "user_id": "66081b1abb620879aedd09be",
        "document_version": 1,
        "body_health": {
          "summary": {
            "body_summary": {
              "body_metrics": {
                ...
                "weight_kg_float": 86,
                "height_cm_int": 185,
                "bmi_float": 25.1
              },
            },
          },
        },
```
