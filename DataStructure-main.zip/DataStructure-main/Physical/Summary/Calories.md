# Calories with Physical Summary

Dataset: Physical Summary - Physical Health

Data: Calories

## Frame

```Json
{
  "calories": {
    "calories_basal_metabolic_rate_kcal_float": 1500,
    "calories_expenditure_kcal_float": 2200,
    "calories_net_active_kcal_float": 700,
    "calories_net_intake_kcal_float": 2000
  }
}
```