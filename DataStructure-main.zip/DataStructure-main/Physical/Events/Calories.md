# Calories with Physical Summary

Dataset: Calories - Activity Event -Physical Health

Data: Calories

## Frame

```Json

"calories": {
  "calories_basal_metabolic_rate_kcal_float": 1800.0,
  "calories_expenditure_kcal_float": 750.0,
  "calories_net_active_kcal_float": 600.0,
  "calories_net_intake_kcal_float": 2500.0,
  "carbohydrate_percentage_of_calories_int": 50,
  "fat_percentage_of_calories_int": 30,
  "protein_percentage_of_calories_int": 20,

```