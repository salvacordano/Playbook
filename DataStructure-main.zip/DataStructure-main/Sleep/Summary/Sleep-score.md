# Sleep Score with Sleep Health

Dataset: Sleep Summary - Sleep Health

Data: Sleep Score

## Frame

```Json
{
    "scores": {
        "sleep_quality_rating_1_5_score_int": 4,
        "sleep_efficiency_1_100_score_int": 85,
        "sleep_goal_seconds_int": 28800,
        "sleep_continuity_1_5_score_int": 4,
        "sleep_continuity_1_5_rating_int": 4
    }
}
```